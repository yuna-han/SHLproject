-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- 호스트: localhost
-- 처리한 시간: 19-12-04 21:40 
-- 서버 버전: 5.1.41
-- PHP 버전: 5.2.12



/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 데이터베이스: `shl`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `department`
--

CREATE TABLE IF NOT EXISTS "department" (
  "deptcode" varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  "deptname" varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY ("deptcode")
);

--
-- 테이블의 덤프 데이터 `department`
--

INSERT INTO `department` (`deptcode`, `deptname`) VALUES
('D01', 'OS'),
('D02', 'IM'),
('D03', 'NS'),
('D04', 'OF'),
('D05', 'DEN');

-- --------------------------------------------------------

--
-- 테이블 구조 `member`
--

CREATE TABLE IF NOT EXISTS "member" (
  "id" varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  "pw" varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  "name" varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  "tell" varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  "email" varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY ("id")
);

--
-- 테이블의 덤프 데이터 `member`
--

INSERT INTO `member` (`id`, `pw`, `name`, `tell`, `email`) VALUES
('1', '1', '1', '1', '1'),
('test2', '123123', 'test2', '010-4455-8855', 'javasiro@naver.com'),
('11111', '555', '123', '123', '123'),
('111116', '555', '123', '123', '123'),
('hanalove', 'haha1234', '박하나', '010-3855-4521', 'hanapark@gmail.com'),
('admin', 'admin', 'admin', '010-2233-4455', 'shl@naver.com'),
('test', '123456', 'test', '010-2233-4455', 'test@naver.com'),
('user01', 'user01', '김유일', '010-1110-5585', 'uilkim@daum.net');

-- --------------------------------------------------------

--
-- 테이블 구조 `reservation`
--

CREATE TABLE IF NOT EXISTS "reservation" (
  "rcode" int(8) NOT NULL AUTO_INCREMENT,
  "rdate" datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  "content" varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  "id" varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  "deptcode" varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY ("rcode"),
  KEY "FK_reservation_2" ("deptcode"),
  KEY "FK_reservation_1" ("id")
) AUTO_INCREMENT=20 ;

--
-- 테이블의 덤프 데이터 `reservation`
--

INSERT INTO `reservation` (`rcode`, `rdate`, `content`, `id`, `deptcode`) VALUES
(3, '2019-11-27 00:00:00', 'ㅁㅁㅁ', '', 'D01'),
(14, '2019-12-05 14:30:00', '속이 쓰리고, 명치 부근에 쿡쿡 찌르는 듯한 통증이 있습니다.', 'test2', 'D02'),
(15, '2019-12-04 10:34:00', '배가 아프고 입맛이 없어요', 'test', 'D01'),
(16, '2019-12-05 10:30:00', '인대가 늘어난거 같아요^^', 'happy', 'D01'),
(17, '2019-12-05 13:00:00', '정밀 검진 예약드립니다.', 'user01', 'D03'),
(18, '2019-12-05 11:30:00', '사랑니가 난 것 같아요ㅠㅠ', 'usertest', 'D05'),
(19, '2019-12-05 18:40:00', '흉터 치료 희망합니다.', 'hanalove', 'D04'),
(5, '2019-12-03 00:00:00', 'ㄴㅁㅇㄴㅁㅇㄴㅁㅇ', '1', 'D01'),
(6, '2019-12-03 00:00:00', '잇힝', '1', 'D01'),
(7, '2019-12-06 00:00:00', '아픔', '11111', 'D04'),
(8, '2019-12-06 00:00:00', '피부 아픔', '11111', 'D04'),
(9, '2019-12-07 00:00:00', '신경 아픔', '11111', 'D03'),
(10, '2019-12-03 00:14:00', '424123', '1', 'D01'),
(11, '2020-12-03 16:34:00', '아파요', '1', 'D01'),
(12, '2023-12-04 16:34:00', '한글', '333', 'D04'),
(13, '2019-12-05 15:00:00', '콧물이 나고 기침이 자주 남.', 'test', 'D02');
